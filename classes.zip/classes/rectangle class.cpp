#include <iostream>
using namespace std;

class Rectangle {
public:
    float length, width;

    float area() 
    {
        return length * width; 
    }
    float peri() { return 2 * (length + width); }

    void display() {
        cout << "Area: " << area() << endl<<"Perimeter: " << peri() << endl;
    }
};

int main() {
    Rectangle rectangle;
    cout << "Enter Length & Width: ";
    cin >> rectangle.length>> r.width;

    rectangle.display();
    return 0;
}