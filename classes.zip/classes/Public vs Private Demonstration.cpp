#include <iostream>

using namespace std;

class Student {
private:
    int marks; 

public:
    char name;   
    int rollNo; 
    void assignMarks(int m) {
        marks = m;
    }
    void display() {
        cout << "Name: " << name << endl;
        cout << "Roll No: " << rollNo << endl;
        cout << "Marks: " << marks << endl;
    }
};

int main() {
    Student s1;

    s1.name = 'A';
    s1.rollNo = 101;
    s1.assignMarks(85);

    cout << " Student Record" << endl;
    s1.display();

    return 0;
}