#include <iostream>
using namespace std;

class BankAccount 
{
public:
    int account_No;
    int balance;
    void deposit(double amount)
    {
        balance += amount;
    }
    void withdraw(int amount)
    {
        if (amount > balance)
            cout << "Insufficient Balance!" << endl;
        else
            balance -= amount;
    }

    void displayDetails() {
        cout << "Acc No: " << account_No << endl<<"Balance: " << balance << endl;
    }
};

int main() 
{
    BankAccount my_account;
    my_account.account_No = 12345;
    my_account.balance = 1000;

    my_account.deposit(500);   
    my_account.withdraw(200);  
    my_account.withdraw(2000); 

    my_account.displayDetails();
    return 0;
}