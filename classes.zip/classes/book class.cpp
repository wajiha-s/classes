#include <iostream>

using namespace std;
class Book {
public:
    int title;
    int author;
    int price;

    void displayInfo()
    {
        cout << "title: " << title << endl;
        cout << "author: " << author << endl;
        cout << "Price: " << price << endl;
    }
};

int main() {
    Book book1;
    book1.title = 101;
    book1.author = 5;
    book1.price = 550.50;
    Book book2;
    book2.title = 102;
    book2.author = 3;
    book2.price = 420;

    cout << " Book Records" << endl;
    book1.displayInfo();
    book2.displayInfo();

    return 0;
}